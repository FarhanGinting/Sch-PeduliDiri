# laravel-pack README

## Create 04-02-2024

Package yang saya buat untuk mempermudah instalasi tool - tool untuk membangun website dengan kerangka kerja laravel

* PHP Debug, PHP Intelephense, PHP Extension Pack, PHP IntelliSense, PHP Namespace Resolver, phpfmt.
* Laravel Artisan, Laravel Blade formatter, Laravel Blade Snippets, Laravel Blade Spacer, Laravel Extra Intellisense, Laravel Goto Controller, Laravel Goto View, Laravel Snippets.
* Auto Rename Tag, Error Lens, Git Graph, Git History, GitLens, Indent Rainbow, Jinja, Material Icon Theme, Material Theme, Prettier, Start git-bash, Tabnine: AI, vscode icon.

## For more information

**Enjoy!**
